class NonSkillRegiModel {
  
}